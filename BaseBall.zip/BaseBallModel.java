
public class BaseBallModel {
	
	BaseBallModel(){
		
	}
}
