
public class BaseBallModel {

}
