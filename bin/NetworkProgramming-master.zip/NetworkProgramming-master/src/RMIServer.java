import java.rmi.*;

public interface RMIServer extends Remote {
	
}
