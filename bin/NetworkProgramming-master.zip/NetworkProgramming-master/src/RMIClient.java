import java.rmi.*;

public interface RMIClient extends Remote {
	
}
